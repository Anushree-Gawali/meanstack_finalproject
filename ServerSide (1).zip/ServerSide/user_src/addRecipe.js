
const mysql = require("mysql");
const Promise = require("bluebird");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);


const config = require("./My_DB_info");


let addmyRecipe = async(input) => {

    try {

        const Connection = mysql.createConnection(config.DB_CONFIG);

        await Connection.connectAsync();

        let sql ="INSERT INTO RECIPE (recipename, COOKINGTIME, INGREDIENTS, directions, categories, image) VALUES(?, ?, ?, ?, ?, ?)";
        await Connection.queryAsync(sql, [

            input.name,
            input.time,
            input.ing,
            input.dir,
            input.cat,
            input.img
        ]);

        await Connection.endAsync();

        console.log("done");

    }
    catch (err) {

        console.log("fail");

    }

}

module.exports = { addmyRecipe };
