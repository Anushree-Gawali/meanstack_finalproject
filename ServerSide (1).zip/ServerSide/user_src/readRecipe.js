
const mysql = require("mysql");
const Promise = require("bluebird");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const config = require("./My_DB_info");


let readMyRecipes = async () => {

    try {

        const Connection = mysql.createConnection(config.DB_CONFIG);

        await Connection.connectAsync();

        let sql = "select * from recipe";
        let result = await Connection.queryAsync(sql);

        await Connection.endAsync();

        return  result ;
    }
    catch (err) {

        console.log("fail");
    }

}

module.exports = { readMyRecipes };


