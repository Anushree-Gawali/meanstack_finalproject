const Promise = require("bluebird");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

//express
const express = require("express");
const app = express();


// for origin and unblocking cors policy
const cors = require("cors");
app.use(cors());


// for conver text to json
app.use(express.json());


//read file
const readfile = require("./readRecipe");

//addfile
const addfile = require("./addRecipe");


// ---------------------------------------------------------------------
// This code is for read recipe

app.get("/read", async (req, res) => {

    try {

        let myresult = await readfile.readMyRecipes();

        res.json(myresult);

    }
    catch (err) {

        console.log("fail database");
    }

});

// ---------------------------------------------------------------------

// This code is for add recipe 

app.post("/addfile", async (req, res) => {


    try {

        const input = req.body; 
        await addfile.addmyRecipe(input);

        res.json({message:"successfully add"});

    }
    catch(err){

        res.json({message:"failure"});

    }
    
});

app.listen(7000);






