const Promise = require("bluebird");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

//express
const express = require("express");
const app = express();


// for origin and unblocking cors policy
const cors = require("cors");
app.use(cors());


// for conver text to json
app.use(express.json());


//addfile
const addtreandfile = require("./addtreand");

// ---------------------------------------------------------------------
// add treand 

app.get("/addtreand", async (req, res) => {

    try {

        let input = req.query;
        await addtreandfile.addmytreand(input);

        res.json({message:"recipe added successfully"});

    }
    catch (err) {

        console.log("fail database");
    }

});



const readreandfile = require("./readTreand");

// ---------------------------------------------------------------------
// add treand 

app.get("/readtreand", async (req, res) => {

    try {

        let myresult = await readreandfile.readmytreand();

        res.json(myresult);

    }
    catch (err) {

        console.log("fail database");
    }

});

app.listen(2000);






