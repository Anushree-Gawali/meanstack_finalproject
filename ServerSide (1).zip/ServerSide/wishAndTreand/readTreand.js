
const mysql = require("mysql");
const Promise = require("bluebird");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);


const config = require("./DB_INFO");


let readmytreand = async() => {

    try {

        const Connection = mysql.createConnection(config.DB_CONFIG);

        await Connection.connectAsync();

        let sql ="select recipe from treanding, recipe where treanding.recipename = recipe.recipename";
        // let sql ="select * from recipe";
        let result = await Connection.queryAsync(sql);

        await Connection.endAsync();
        
        return result;
        
    }
    catch (err) {

    }

}

module.exports = { readmytreand };
