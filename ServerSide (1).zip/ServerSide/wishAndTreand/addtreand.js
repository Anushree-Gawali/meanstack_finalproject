
const mysql = require("mysql");
const Promise = require("bluebird");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);


const config = require("./DB_INFO");


let addmytreand = async(input) => {

    try {

        const Connection = mysql.createConnection(config.DB_CONFIG);

        await Connection.connectAsync();

        let sql ="INSERT INTO treanding (recipename) VALUES(?)";
        await Connection.queryAsync(sql, [

            input.recipename,

        ]);

        await Connection.endAsync();

    }
    catch (err) {

    }

}

module.exports = { addmytreand };
