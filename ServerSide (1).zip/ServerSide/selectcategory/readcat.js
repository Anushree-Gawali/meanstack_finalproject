
const mysql = require("mysql");
const Promise = require("bluebird");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const config = require("./My_DB_info");


let selectcat = async (input) => {

    try {

        const Connection = mysql.createConnection(config.DB_CONFIG);

        await Connection.connectAsync();

        let sql = "select * from  recipe where categories = ?";

        let result = await Connection.queryAsync(sql,[

            input.categories
        ]);

        await Connection.endAsync();

        return  result ;

    }
    catch (err) {

        console.log("fail db");
    }

}

module.exports = { selectcat };


