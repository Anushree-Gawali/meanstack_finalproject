const Promise = require("bluebird");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

//express
const express = require("express");
const app = express();


// for origin and unblocking cors policy
const cors = require("cors");
app.use(cors());


// for conver text to json
app.use(express.json());


//read file
const readfile = require("./readcat");



// ---------------------------------------------------------------------
// This code is for read recipe

app.get("/readcat", async (req, res) => {

    try {

        const input = req.query;

        let result = await readfile.selectcat(input);

        res.json(result);
    }
    catch (err) {

        res.json({message:"fail"});
        console.log("fail");
    }

});

app.listen(3000);






