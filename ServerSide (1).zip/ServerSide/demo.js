

let fun  = async() => {


    let name = document.querySelector("#name").value;
    let time = document.querySelector("#time").value;
    let ing = document.querySelector("#ing").value;
    let dir = document.querySelector("#dir").value;
    let cat = document.querySelector("#cat").value;
    let img = document.querySelector("#img").value;



    let user_input = {

        name,
        time,
        ing,
        dir,
        cat,
        img
    }

    let url = "http://localhost:7000/addfile";
    
    // by default it makes GET call.
    let result = await fetch(url,{
     
      method: "post",
      body: JSON.stringify(user_input),   // JSON to text
      headers:{"Content-Type":"application/json"}

    });

    let commits = await result.json();
    console.log(commits.message);

}