
const promise = require("bluebird");

promise.promisifyAll(require("mysql/lib/Connection").prototype);
promise.promisifyAll(require("mysql/lib/Pool").prototype);

const express = require("express");
const app = express();

const cors = require("cors");
app.use(cors());

app.use(express.json());

const register = require("./reg");

app.post("/register", async (req, res) => {

    try {

        const input1 = req.body;

        await register.registerUser(input1);

        console.log("successfully register")
        res.json({ message: "successfully register" });

    } catch (err) {

        console.log("something wrong");
        res.json({ message: "something wrong" });

    }
});

app.post("/auth-user", async (req, res) => {
   
    try {

      let input = req.body;
      
      await register.authenticateUser(input);
      
      res.json({ opr: true });

    } catch (err) {
      res.json({ opr: false });
    }
  });

app.listen(9000);