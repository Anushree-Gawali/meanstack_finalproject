let DB_info = {

    host:"127.0.0.1",
    user:"root",
    password:"abdavane",
    database:"recipebook"
}

module.exports = { DB_info };