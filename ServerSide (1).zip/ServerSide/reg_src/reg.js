const mysql = require("mysql");
const promise = require("bluebird");

promise.promisifyAll(require("mysql/lib/Connection").prototype);
promise.promisifyAll(require("mysql/lib/Pool").prototype);

const config = require("./data_info");

let registerUser = async (input) => {

    try {

        const connection = mysql.createConnection(config.DB_info);

        await connection.connectAsync();

        let sql = "INSERT INTO users (fname, lname, email, password) VALUES(?, ?, ?, ?)";

        await connection.queryAsync(sql, [

            input.fname,
            input.lname,
            input.email,
            input.password
        
        ])

        await connection.endAsync();

        console.log("pass");

    } catch (err) {

        console.log("fail");

    }
};


let authenticateUser = async (input) => {
    const connection = mysql.createConnection(config.DB_info);
    await connection.connectAsync();


    let sql = "SELECT * FROM USERS WHERE email=? AND password=?"
    const results = await connection.queryAsync(sql,[

        input.email,
        input.password
    ]);

    await connection.endAsync();

    console.log(results);

    if (results.length == 0) {
        throw new Error("Invalid Credentials");
    }
};

module.exports = { registerUser, authenticateUser };